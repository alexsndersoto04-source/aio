//! Stable metadata for functions callable from Titan bytecode.
//!
//! Implementations live in `titan_vm`, where host values can be converted to
//! VM values. Keeping names/signatures here gives type checking and codegen one
//! authoritative registry without introducing a crate dependency cycle.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NativeType { Any, Int, Float, Bool, String, Bytes, Array, Map, Nil }

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Capability { None, Filesystem, Process, Network, Environment }

#[derive(Debug, Clone, Copy)]
pub struct NativeSignature {
    pub name: &'static str,
    pub params: &'static [NativeType],
    pub result: NativeType,
    pub capability: Capability,
}

macro_rules! native {
    ($name:literal, [$($param:ident),*], $result:ident) => { NativeSignature { name: $name, params: &[$(NativeType::$param),*], result: NativeType::$result, capability: Capability::None } };
    ($name:literal, [$($param:ident),*], $result:ident, $capability:ident) => { NativeSignature { name: $name, params: &[$(NativeType::$param),*], result: NativeType::$result, capability: Capability::$capability } };
}

pub static NATIVES: &[NativeSignature] = &[
    native!("std::text::length", [String], Int), native!("std::text::reverse", [String], String),
    native!("std::text::uppercase", [String], String), native!("std::text::lowercase", [String], String),
    native!("std::text::trim", [String], String), native!("std::text::capitalize", [String], String),
    native!("std::text::escape_html", [String], String), native!("std::text::slugify", [String], String),
    native!("std::text::levenshtein", [String, String], Int), native!("std::text::equals", [String, String], Bool),
    native!("std::text::hash64", [String], Int), native!("std::text::contains", [String, String], Bool),
    native!("std::text::starts_with", [String, String], Bool), native!("std::text::ends_with", [String, String], Bool),
    native!("std::text::replace", [String, String, String], String), native!("std::text::truncate", [String, Int, String], String),
    native!("std::text::words", [String], Array), native!("std::text::lines", [String], Array),

    native!("std::encoding::hex_encode", [Bytes], String), native!("std::encoding::hex_decode", [String], Bytes),
    native!("std::encoding::base64_encode", [Bytes], String), native!("std::encoding::base64_decode", [String], Bytes),
    native!("std::encoding::percent_encode", [String], String), native!("std::encoding::percent_decode", [String], String),
    native!("std::encoding::utf8_encode", [String], Bytes), native!("std::encoding::utf8_decode", [Bytes], String),

    native!("std::checksum::fnv1a64", [Bytes], Int), native!("std::checksum::crc32", [Bytes], Int),
    native!("std::checksum::constant_time_eq", [Bytes, Bytes], Bool),
    native!("std::bytes::from_array", [Array], Bytes), native!("std::bytes::to_array", [Bytes], Array),
    native!("std::bytes::length", [Bytes], Int), native!("std::bytes::concat", [Bytes, Bytes], Bytes),
    native!("std::bytes::slice", [Bytes, Int, Int], Bytes), native!("std::bytes::read_u32_le", [Bytes, Int], Int),
    native!("std::bytes::write_u32_le", [Int], Bytes),

    native!("std::http::parse_request", [Bytes], Any), native!("std::http::build_response", [Int, Map, Bytes, Bool], Bytes),
    native!("std::http::reason_phrase", [Int], String),
    native!("std::http::route_match", [String, String], Any), native!("std::http::parse_query", [String, Int], Map),
    native!("std::http::security_headers", [Map], Map), native!("std::http::cors", [Map, String, String], Map),
    native!("std::http::request_id", [Map], Map), native!("std::http::rate_limit", [String, Int, Int], Bool),
    native!("std::http::json_response", [Int, Any], Map), native!("std::http::error_response", [Int, String], Map),
    native!("std::http::request", [String, String, Map, Bytes, Int, Int, Int], Map),
    native!("std::http::parse_multipart", [String, Bytes, Int, Int], Array),
    native!("std::metrics::counter_add", [String, Int], Int), native!("std::metrics::gauge_set", [String, Float], Nil),
    native!("std::metrics::histogram_record", [String, Float], Nil), native!("std::metrics::snapshot", [], Map), native!("std::metrics::reset", [], Nil),
    native!("std::ws::accept_key", [String], String), native!("std::ws::upgrade_response", [String, String], Bytes),
    native!("std::ws::validate_upgrade", [Map, String], Bytes), native!("std::ws::validate_accept", [Bytes, String], Bool),
    native!("std::ws::encode", [Int, Bytes, Bool], Bytes), native!("std::ws::parse", [Bytes, Bool, Int], Any),
    native!("std::csv::parse", [String], Array), native!("std::csv::serialize", [Array], String),
    native!("std::json::parse", [String], Any), native!("std::json::stringify", [Any], String),
    native!("std::json::pretty", [Any], String), native!("std::json::pointer", [Any, String], Any),
    native!("std::json::merge", [Any, Any], Any), native!("std::json::flatten", [Any], Array),

    native!("std::array::set", [Array, Int, Any], Array),
    native!("std::array::push", [Array, Any], Array),
    native!("std::array::pop", [Array], Array),
    native!("std::array::slice", [Array, Int, Int], Array),
    native!("std::array::concat", [Array, Array], Array),
    native!("std::wasm::heap_used", [], Int),
    native!("std::wasm::heap_capacity", [], Int),
    native!("std::wasm::heap_limit", [], Int),
    native!("std::wasm::heap_set_limit", [Int], Bool),
    native!("std::wasm::heap_checkpoint", [], Int),
    native!("std::wasm::heap_restore", [Int], Bool),
    native!("std::wasm::heap_allocations", [], Int),
    native!("std::wasm::heap_allocated_bytes", [], Int),
    native!("std::wasm::heap_restores", [], Int),
    native!("std::wasm::heap_reclaimed_bytes", [], Int),
    native!("std::wasm::heap_peak_used", [], Int),
    native!("std::wasm::heap_reset_counters", [], Bool),
    native!("std::wasm::heap_scope_begin", [], Int),
    native!("std::wasm::heap_scope_end", [Int], Bool),
    native!("std::collections::length", [Any], Int), native!("std::collections::contains", [Array, Any], Bool),
    native!("std::collections::reverse", [Array], Array), native!("std::collections::deduplicate", [Array], Array),
    native!("std::collections::join", [Array, String], String), native!("std::collections::chunk", [Array, Int], Array),
    native!("std::map::new", [], Map), native!("std::map::length", [Map], Int),
    native!("std::map::insert_new", [Map, String, Any], Map),
    native!("std::map::keys", [Map], Array), native!("std::map::values", [Map], Array),
    native!("std::map::contains", [Map, String], Bool), native!("std::map::get", [Map, String], Any),
    native!("std::map::insert", [Map, String, Any], Map), native!("std::map::remove", [Map, String], Map),

    native!("std::math::sqrt", [Float], Float), native!("std::math::pow", [Float, Float], Float),
    native!("std::math::sin", [Float], Float), native!("std::math::cos", [Float], Float),
    native!("std::math::tan", [Float], Float), native!("std::math::ln", [Float], Float),
    native!("std::math::abs", [Float], Float), native!("std::math::floor", [Float], Float),
    native!("std::math::ceil", [Float], Float), native!("std::math::round", [Float], Float),
    native!("std::stats::mean", [Array], Float), native!("std::stats::median", [Array], Float),
    native!("std::stats::quantile", [Array, Float], Float), native!("std::stats::variance", [Array], Float),
    native!("std::stats::stddev", [Array], Float),

    native!("std::time::unix_seconds", [], Int), native!("std::time::unix_millis", [], Int),
    native!("std::time::sleep_ms", [Int], Nil),

    native!("std::path::join", [String, String], String), native!("std::path::normalize", [String], String),
    native!("std::path::parent", [String], String), native!("std::path::file_name", [String], String),
    native!("std::path::stem", [String], String), native!("std::path::extension", [String], String),
    native!("std::path::absolute", [String], String, Filesystem), native!("std::path::canonical", [String], String, Filesystem),

    native!("std::fs::read_text", [String], String, Filesystem), native!("std::fs::read_bytes", [String], Bytes, Filesystem),
    native!("std::fs::write_text", [String, String], Nil, Filesystem), native!("std::fs::write_bytes", [String, Bytes], Nil, Filesystem),
    native!("std::fs::atomic_write", [String, Bytes], Nil, Filesystem), native!("std::fs::append", [String, Bytes], Nil, Filesystem),
    native!("std::fs::exists", [String], Bool, Filesystem), native!("std::fs::is_file", [String], Bool, Filesystem),
    native!("std::fs::is_dir", [String], Bool, Filesystem), native!("std::fs::create_dir", [String], Nil, Filesystem),
    native!("std::fs::remove_file", [String], Nil, Filesystem), native!("std::fs::remove_dir", [String], Nil, Filesystem),
    native!("std::fs::list_dir", [String], Array, Filesystem), native!("std::fs::file_size", [String], Int, Filesystem),
    native!("std::fs::copy", [String, String], Int, Filesystem), native!("std::fs::rename", [String, String], Nil, Filesystem),

    native!("std::process::run", [String, Array], Map, Process),
    native!("std::process::run_timeout", [String, Array, Int], Map, Process),
    native!("std::env::get", [String], String, Environment), native!("std::env::args", [], Array, Environment),
    native!("std::env::current_dir", [], String, Environment),
    native!("std::net::http_get", [String], Map, Network),

    native!("std::web::query_exists", [String], Bool),
    native!("std::web::set_text", [String, String], Nil),
    native!("std::web::set_html", [String, String], Nil),
    native!("std::web::set_attribute", [String, String, String], Nil),
    native!("std::web::add_class", [String, String], Nil),
    native!("std::web::remove_class", [String, String], Nil),
    native!("std::web::focus", [String], Nil),
    native!("std::web::set_title", [String], Nil),
    native!("std::web::listen", [String, String, String], Int),
    native!("std::web::unlisten", [Int], Bool),
    native!("std::web::event_type", [], String),
    native!("std::web::event_value", [], String),
    native!("std::web::event_key", [], String),
    native!("std::web::event_target_id", [], String),
    native!("std::web::event_checked", [], Bool),
    native!("std::web::event_x", [], Int),
    native!("std::web::event_y", [], Int),
    native!("std::web::fetch", [String, Int, Int, String], Int),
    native!("std::web::fetch_cancel", [Int], Bool),
    native!("std::web::fetch_ok", [], Bool),
    native!("std::web::fetch_status", [], Int),
    native!("std::web::fetch_body", [], String),
    native!("std::web::fetch_url", [], String),
    native!("std::web::fetch_error", [], String),
    native!("std::web::fetch_headers", [], String),
    native!("std::web::request", [String, String, String, String, Int, Int, String], Int),
    native!("std::web::ws_connect", [String, String, Int, String, String, String, String], Int),
    native!("std::web::ws_send", [Int, String], Bool),
    native!("std::web::ws_close", [Int, Int, String], Bool),
    native!("std::web::ws_id", [], Int),
    native!("std::web::ws_message", [], String),
    native!("std::web::ws_protocol", [], String),
    native!("std::web::ws_close_code", [], Int),
    native!("std::web::ws_close_reason", [], String),
    native!("std::web::ws_was_clean", [], Bool),
    native!("std::web::ws_error", [], String),
    native!("std::web::canvas_resize", [String, Int, Int], Nil),
    native!("std::web::canvas_clear", [String, String], Nil),
    native!("std::web::canvas_fill_rect", [String, Int, Int, Int, Int, String], Nil),
    native!("std::web::canvas_stroke_rect", [String, Int, Int, Int, Int, String, Int], Nil),
    native!("std::web::canvas_line", [String, Int, Int, Int, Int, String, Int], Nil),
    native!("std::web::canvas_text", [String, String, Int, Int, String, String], Nil),
    native!("std::web::animation_start", [String], Int),
    native!("std::web::animation_cancel", [Int], Bool),
    native!("std::web::frame_id", [], Int),
    native!("std::web::frame_time_ms", [], Int),
    native!("std::web::frame_delta_ms", [], Int),
    native!("std::web::frame_count", [], Int),
    native!("std::web::webgl_supported", [String], Bool),
    native!("std::web::webgl_create", [String, String, String, String, String], Int),
    native!("std::web::webgl_uniform_f32", [Int, String, Int, Int], Bool),
    native!("std::web::webgl_draw", [Int, String], Bool),
    native!("std::web::webgl_delete", [Int], Bool),

    native!("std::window::create", [String, Int, Int], Int),
    native!("std::window::is_open", [Int], Bool),
    native!("std::window::close", [Int], Bool),
    native!("std::window::set_title", [Int, String], Bool),
    native!("std::window::resize", [Int, Int, Int], Bool),
    native!("std::window::poll_events", [Int], Array),

    native!("std::input::is_key_pressed", [String], Bool),
    native!("std::input::mouse_pos", [], Array),
    native!("std::input::is_mouse_button_pressed", [Int], Bool),
    native!("std::input::touch_pos", [Int], Array),
    native!("std::clipboard::get_text", [], String),
    native!("std::clipboard::set_text", [String], Bool),
    native!("std::notify::send", [String, String], Bool),
    native!("std::mobile::state", [], String),
    native!("std::mobile::trigger", [String], Bool),
    native!("std::mobile::poll_events", [], Array),
    native!("std::game::init", [String, Int, Int], Bool),
    native!("std::game::step", [], Float),
    native!("std::game::fps", [], Int),
    native!("std::game::check_collision", [Float, Float, Float, Float, Float, Float, Float, Float], Bool),
    native!("std::audio::init", [], Bool),
    native!("std::audio::load_wave", [Float, Int], Int),
    native!("std::audio::sample_count", [Int], Int),
    native!("std::audio::play", [Int, Bool], Bool),
    native!("std::audio::set_volume", [Int, Float], Bool),
    native!("std::audio::stop", [Int], Bool),
    native!("std::gui::init", [], Bool),
    native!("std::gui::create_container", [String, Int, Int], Int),
    native!("std::gui::add_button", [Int, String, Int, Int, Int, Int], Int),
    native!("std::gui::add_label", [Int, String, Int, Int], Int),
    native!("std::gui::set_text", [Int, String], Bool),
    native!("std::gui::get_text", [Int], String),
    native!("std::gui::trigger_click", [Int], Bool),
    native!("std::gui::is_clicked", [Int], Bool),
    native!("std::gui::child_count", [Int], Int),
    native!("std::gui::shutdown", [], Bool),
    native!("std::freestanding::init", [String], Bool),
    native!("std::freestanding::validate_target_spec", [String], Bool),
    native!("std::freestanding::generate_linker_script", [String, Int, Int], String),
    native!("std::freestanding::generate_startup_asm", [String, String], String),
    native!("std::freestanding::get_active_target", [], String),
    native!("std::freestanding::shutdown", [], Bool),
    native!("std::freestanding_memory::init_frame_allocator", [Int, Int], Bool),
    native!("std::freestanding_memory::allocate_frame", [], Int),
    native!("std::freestanding_memory::deallocate_frame", [Int], Bool),
    native!("std::freestanding_memory::map_page", [Int, Int, Int], Bool),
    native!("std::freestanding_memory::translate_page", [Int], Int),
    native!("std::freestanding_memory::free_frames_count", [], Int),
    native!("std::freestanding_memory::shutdown", [], Bool),
    native!("std::freestanding_cpu::init_exception_table", [Int], Bool),
    native!("std::freestanding_cpu::register_exception_handler", [Int, Int], Bool),
    native!("std::freestanding_cpu::dispatch_exception", [Int, Int, Int], Int),
    native!("std::freestanding_cpu::register_syscall_handler", [Int, Int], Bool),
    native!("std::freestanding_cpu::invoke_syscall", [Int, Int, Int, Int], Int),
    native!("std::freestanding_cpu::get_last_fault_addr", [], Int),
    native!("std::freestanding_cpu::shutdown", [], Bool),
    native!("std::freestanding_mmio::init_mmio_region", [Int, Int], Bool),
    native!("std::freestanding_mmio::read_mmio_u32", [Int], Int),
    native!("std::freestanding_mmio::write_mmio_u32", [Int, Int], Bool),
    native!("std::freestanding_mmio::serial_init", [Int, Int], Bool),
    native!("std::freestanding_mmio::serial_write_str", [String], Int),
    native!("std::freestanding_mmio::serial_get_buffer", [], String),
    native!("std::freestanding_mmio::shutdown", [], Bool),

    native!("std::testing::assert", [Bool, String], Nil), native!("std::testing::assert_eq", [Any, Any, String], Nil),

    // --- Phase 1: regex ---
    native!("std::regex::is_match",     [String, String], Bool),
    native!("std::regex::find",         [String, String], String),
    native!("std::regex::find_all",     [String, String], Array),
    native!("std::regex::captures",     [String, String], Array),
    native!("std::regex::replace_all",  [String, String, String], String),
    native!("std::regex::split",        [String, String], Array),
    native!("std::regex::is_valid",     [String], Bool),

    // --- Phase 1: uuid ---
    native!("std::uuid::v4",        [], String),
    native!("std::uuid::v7",        [], String),
    native!("std::uuid::is_valid",  [String], Bool),
    native!("std::uuid::normalize", [String], String),
    native!("std::uuid::nil",       [], String),

    // --- Phase 1: hash ---
    native!("std::hash::sha256",       [Bytes], String),
    native!("std::hash::sha384",       [Bytes], String),
    native!("std::hash::sha512",       [Bytes], String),
    native!("std::hash::sha3_256",     [Bytes], String),
    native!("std::hash::sha3_512",     [Bytes], String),
    native!("std::hash::blake3",       [Bytes], String),
    native!("std::hash::sha256_bytes", [Bytes], Bytes),
    native!("std::hash::sha512_bytes", [Bytes], Bytes),
    native!("std::hash::blake3_bytes", [Bytes], Bytes),
    native!("std::hash::hmac_sha256",  [Bytes, Bytes], String),
    native!("std::hash::hmac_sha512",  [Bytes, Bytes], String),

    // --- Phase 1: random ---
    native!("std::random::int",           [], Int),
    native!("std::random::range",         [Int, Int], Int),
    native!("std::random::float",         [], Float),
    native!("std::random::bool",          [], Bool),
    native!("std::random::bytes",         [Int], Bytes),
    native!("std::random::seeded_int",    [Int, Int, Int], Int),
    native!("std::random::seeded_float",  [Int], Float),
    native!("std::random::seeded_bytes",  [Int, Int], Bytes),

    // --- Phase 1: datetime ---
    native!("std::datetime::now",           [], Int),
    native!("std::datetime::now_iso",       [], String),
    native!("std::datetime::format",        [Int, String], String),
    native!("std::datetime::to_rfc3339",    [Int], String),
    native!("std::datetime::to_rfc2822",    [Int], String),
    native!("std::datetime::parse_rfc3339", [String], Int),
    native!("std::datetime::parse",         [String, String], Int),
    native!("std::datetime::utc_ymd_hms",   [Int, Int, Int, Int, Int, Int], Int),
    native!("std::datetime::add_seconds",   [Int, Int], Int),
    native!("std::datetime::add_days",      [Int, Int], Int),
    native!("std::datetime::diff_seconds",  [Int, Int], Int),
    native!("std::datetime::year",          [Int], Int),
    native!("std::datetime::month",         [Int], Int),
    native!("std::datetime::day",           [Int], Int),
    native!("std::datetime::hour",          [Int], Int),
    native!("std::datetime::minute",        [Int], Int),
    native!("std::datetime::second",        [Int], Int),
    native!("std::datetime::weekday",       [Int], Int),
    native!("std::datetime::format_offset", [Int, String, Int], String),

    // --- Phase 1: url ---
    native!("std::url::is_valid",    [String], Bool),
    native!("std::url::scheme",      [String], String),
    native!("std::url::host",        [String], String),
    native!("std::url::port",        [String], Int),
    native!("std::url::path",        [String], String),
    native!("std::url::query",       [String], String),
    native!("std::url::fragment",    [String], String),
    native!("std::url::parse_query", [String], Map),
    native!("std::url::build_query", [Array], String),
    native!("std::url::join",        [String, String], String),

    // --- Phase 2: compress ---
    native!("std::compress::gzip_encode",    [Bytes, Int], Bytes),
    native!("std::compress::gzip_decode",    [Bytes], Bytes),
    native!("std::compress::zlib_encode",    [Bytes, Int], Bytes),
    native!("std::compress::zlib_decode",    [Bytes], Bytes),
    native!("std::compress::deflate_encode", [Bytes, Int], Bytes),
    native!("std::compress::deflate_decode", [Bytes], Bytes),
    native!("std::compress::zstd_encode",    [Bytes, Int], Bytes),
    native!("std::compress::zstd_decode",    [Bytes], Bytes),

    // --- Phase 2: archive ---
    native!("std::archive::tar_pack",   [Array], Bytes),
    native!("std::archive::tar_unpack", [Bytes], Array),
    native!("std::archive::zip_pack",   [Array], Bytes),
    native!("std::archive::zip_unpack", [Bytes], Array),
    native!("std::archive::zip_list",   [Bytes], Array),

    // --- Phase 2: yaml ---
    native!("std::yaml::parse",       [String], Any),
    native!("std::yaml::stringify",   [Any], String),
    native!("std::yaml::parse_multi", [String], Array),

    // --- Phase 2: xml ---
    native!("std::xml::parse",         [String], Any),
    native!("std::xml::stringify",     [Any], String),
    native!("std::xml::escape_text",   [String], String),
    native!("std::xml::escape_attr",   [String], String),

    // --- Phase 3: http_full (HTTPS client via ureq + rustls) ---
    // Signature: (method, url, headers_map, body_bytes, options_map) -> response_map
    // options_map keys: basic_user, basic_pass, bearer, user_agent, timeout_ms, max_redirects
    native!("std::http_full::request",   [String, String, Map, Bytes, Map], Map, Network),
    native!("std::http_full::get_json",  [String, Map, Map], Any, Network),
    native!("std::http_full::post_json", [String, Any, Map, Map], Any, Network),
    native!("std::http_full::post_form", [String, Array, Map, Map], Map, Network),

    // --- Phase 3: dns ---
    native!("std::dns::resolve",       [String], Array, Network),
    native!("std::dns::resolve_ipv4",  [String], Array, Network),
    native!("std::dns::resolve_ipv6",  [String], Array, Network),
    native!("std::dns::resolve_mx",    [String], Array, Network),
    native!("std::dns::resolve_txt",   [String], Array, Network),
    native!("std::dns::resolve_cname", [String], Array, Network),
    native!("std::dns::reverse",       [String], Array, Network),

    // --- Phase 3: email (SMTP+TLS via lettre + rustls) ---
    native!("std::email::send_simple",          [String, Int, String, String, String, String, String, String], String, Network),
    native!("std::email::send_html",            [String, Int, String, String, String, String, String, String, String], String, Network),
    native!("std::email::send_with_attachment", [String, Int, String, String, String, String, String, String, String, String, Bytes], String, Network),

    // --- Phase 4: crypto (AEAD) ---
    native!("std::crypto::generate_key_32",   [], Bytes),
    native!("std::crypto::generate_nonce",    [], Bytes),
    native!("std::crypto::chacha20_encrypt",  [Bytes, Bytes, Bytes, Bytes], Bytes),
    native!("std::crypto::chacha20_decrypt",  [Bytes, Bytes, Bytes, Bytes], Bytes),
    native!("std::crypto::chacha20_seal",     [Bytes, Bytes, Bytes], Bytes),
    native!("std::crypto::chacha20_open",     [Bytes, Bytes, Bytes], Bytes),
    native!("std::crypto::aes_gcm_encrypt",   [Bytes, Bytes, Bytes, Bytes], Bytes),
    native!("std::crypto::aes_gcm_decrypt",   [Bytes, Bytes, Bytes, Bytes], Bytes),
    native!("std::crypto::aes_gcm_seal",      [Bytes, Bytes, Bytes], Bytes),
    native!("std::crypto::aes_gcm_open",      [Bytes, Bytes, Bytes], Bytes),

    // --- Phase 4: password (Argon2id + bcrypt) ---
    native!("std::password::hash_argon2",   [String], String),
    native!("std::password::verify_argon2", [String, String], Bool),
    native!("std::password::hash_bcrypt",   [String, Int], String),
    native!("std::password::verify_bcrypt", [String, String], Bool),

    // --- Phase 4: JWT (HS256 + RS256) ---
    native!("std::jwt::sign_hs256",   [Any, Bytes], String),
    native!("std::jwt::verify_hs256", [String, Bytes, String, String], Any),
    native!("std::jwt::sign_rs256",   [Any, Bytes], String),
    native!("std::jwt::verify_rs256", [String, Bytes, String, String], Any),
    native!("std::jwt::peek_header",  [String], Any),

    // --- Phase 5: Termux / Android integration ---
    // Every helper spawns the matching `termux-*` CLI. Needs Termux:API + `pkg install termux-api`.
    // Marked `Process` so `titan run --sandbox` blocks them consistently with `std::process::*`.
    native!("std::termux::is_available",     [], Bool),
    native!("std::termux::battery_status",   [], Any, Process),
    native!("std::termux::wifi_info",        [], Any, Process),
    native!("std::termux::telephony_info",   [], Any, Process),
    native!("std::termux::location",         [String, String], Any, Process),
    native!("std::termux::sensor_list",      [], Array, Process),
    native!("std::termux::sensor_read",      [String], Any, Process),
    native!("std::termux::clipboard_get",    [], String, Process),
    native!("std::termux::clipboard_set",    [String], Nil, Process),
    native!("std::termux::vibrate",          [Int, Bool], Nil, Process),
    native!("std::termux::torch",            [Bool], Nil, Process),
    native!("std::termux::toast",            [String], Nil, Process),
    native!("std::termux::notify",           [String, String, Int], Nil, Process),
    native!("std::termux::notify_remove",    [Int], Nil, Process),
    native!("std::termux::tts_speak",        [String], Nil, Process),
    native!("std::termux::sms_list",         [Int], Any, Process),
    native!("std::termux::sms_send",         [String, String], Nil, Process),
    native!("std::termux::contacts",         [], Any, Process),
    native!("std::termux::camera_info",      [], Any, Process),
    native!("std::termux::camera_photo",     [String, String], Nil, Process),
    native!("std::termux::brightness",       [Int], Nil, Process),
    native!("std::termux::dialog",           [String, String], Any, Process),
    native!("std::termux::share",            [String], Nil, Process),

    // --- Phase 1: dirs ---
    native!("std::dirs::home",       [], String),
    native!("std::dirs::config",     [], String),
    native!("std::dirs::cache",      [], String),
    native!("std::dirs::data",       [], String),
    native!("std::dirs::data_local", [], String),
    native!("std::dirs::state",      [], String),
    native!("std::dirs::executable", [], String),
    native!("std::dirs::runtime",    [], String),
    native!("std::dirs::preference", [], String),
    native!("std::dirs::desktop",    [], String),
    native!("std::dirs::documents",  [], String),
    native!("std::dirs::downloads",  [], String),
    native!("std::dirs::pictures",   [], String),
    native!("std::dirs::music",      [], String),
    native!("std::dirs::videos",     [], String),
    native!("std::dirs::public",     [], String),
    native!("std::dirs::temp",       [], String),
    native!("std::dirs::current",    [], String),
];

pub fn lookup(name: &str) -> Option<&'static NativeSignature> { NATIVES.iter().find(|signature| signature.name == name) }
pub fn contains(name: &str) -> bool { lookup(name).is_some() }

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashSet;

    #[test]
    fn registry_names_are_unique_and_qualified() {
        let mut names = HashSet::new();
        for signature in NATIVES {
            assert!(signature.name.starts_with("std::"));
            assert!(names.insert(signature.name), "duplicate native {}", signature.name);
        }
        assert!(NATIVES.len() >= 80);
    }
}
